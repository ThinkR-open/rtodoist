
<!-- README.md is generated from README.Rmd. Please edit that file -->

# rtodoist <img src="man/figures/logo.png" align="right" alt="" width="120" />

<!-- badges: start -->

[![R build
status](https://github.com/ThinkR-open/rtodoist/workflows/R-CMD-check/badge.svg)](https://github.com/ThinkR-open/rtodoist/actions)
[![Lifecycle:
stable](https://img.shields.io/badge/lifecycle-stable-brightgreen.svg)](https://lifecycle.r-lib.org/articles/stages.html#stable)
[![CRAN
status](https://www.r-pkg.org/badges/version/rtodoist)](https://CRAN.R-project.org/package=rtodoist)
[![R-CMD-check](https://github.com/ThinkR-open/rtodoist/workflows/R-CMD-check/badge.svg)](https://github.com/ThinkR-open/rtodoist/actions)
<!-- badges: end -->

This package allows to use the todoist API. You will be able to add
projects and tasks to your todoist account.

To find information about todoist API :

<https://developer.todoist.com/api/v1/>

## Installation

You can install from CRAN :

``` r
install.packages("rtodoist")
```

You can install the development version of rtodoist with:

``` r
remotes::install_github("ThinkR-open/rtodoist")
```

## Example

``` r
library(rtodoist)

add_project("test") %>%
  add_tasks_in_project("my_task")
```

To find more details about the features, look at the ‘How it works’
vignette.
