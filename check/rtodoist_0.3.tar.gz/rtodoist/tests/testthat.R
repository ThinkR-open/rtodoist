# This file is part of the standard setup for testthat.
# It is recommended that you do not modify it.
#
# Where should you do your testing?
# Learn more about testing at https://r-pkgs.org/tests.html

library(testthat)
library(rtodoist)

test_check("rtodoist")
